package utils;

//NICHT BEARBEITEN
public enum Direction {
	UP, DOWN, RIGHT, LEFT, NONE;
}
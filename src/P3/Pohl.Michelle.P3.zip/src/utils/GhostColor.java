package utils;

//NICHT BEARBEITEN
public enum GhostColor {
	RED, PINK, ORANGE, BLUE;
}
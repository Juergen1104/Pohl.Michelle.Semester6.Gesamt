package utils;

//NICHT BEARBEITEN
public enum Type {
	WALL, DOT, EMPTY;
}
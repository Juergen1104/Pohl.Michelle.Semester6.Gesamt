package main;

import game.GameWindow;

//NICHT BEARBEITEN
public class Main {

	public static void main(String[] args) {
		GameWindow.launch();
	}
}